<?php
include 'base.php';

if($_SESSION['des']=='HOD'){
    header("Refresh:0; url=home.php?load_hod=true");
}elseif($_SESSION['des']=='DEAN'){
    header("Refresh:0; url=home.php?load_dean=true");
}elseif($_SESSION['des']=='FAC'){
    header("Refresh:0; url=home.php?load_hod=true");
}elseif($_SESSION['des']=='STF'){
    header("Refresh:0; url=home.php?load_hod=true");
}elseif($_SESSION['des']=='STU'){
    header("Refresh:0; url=home.php?load_hod=true");
}else{
    header("Refresh:0; url=logout.php");
}
    
?>