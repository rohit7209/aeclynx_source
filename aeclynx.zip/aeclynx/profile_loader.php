<?php
//error_reporting(0);
include 'base.php';

if(isset($_GET['load_all_active_profile'])){
    load_all_active_profile($con);
}
