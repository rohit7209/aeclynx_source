<?php include 'base.php';?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN">
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
    <title>Notifications & Updates</title>
    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    
    <script type="text/javascript" src="jquery-2.2.2.min.js"></script>	
    <script type="text/javascript" src="update.js"></script>
</head>

<body>
    <!--navigation links-->
    <nav class="white" role="navigation">
        <div class="nav-wrapper container" style="width:100%">
            <a id="logo-container" href="#" class="brand-logo">AEC Lynx</a>
            <ul class="right hide-on-med-and-down">
                <li><a href="index.php">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>

            <ul id="nav-mobile" class="side-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
            <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
        </div>
    </nav>
    
    <!-- registration form -->
	<div class="container">
		<div class="row" style="text-align: center;margin-top: 20px">    
	        <div id="error_chip" class="chip" style="display:none">
	            <i class="material-icons">close</i>
	        </div>
	    </div>  
    	<form method="post" action="function_handler.php?create_hod_account=true" class="col s12">
			    <div class="row" style="text-align: center">
					<h2 class="profile-head">Fill up the form as instructed<h2>
				</div>
				
			    <!-- personal details -->
			    <div class="row">
					<h2 class="profile-head">Personal Details:<h2>
				</div>
				
			    <div class="row">
					<div class="input-field col s6">
						<select name="salute" id="salute">
					       	<option value="" disabled selected>Choose your option</option>
					        <option value="Mr.">Mr.</option>
					        <option value="Mrs.">Mrs.</option>
					        <option value="Dr.">Dr.</option>
					        <option value="Er.">Er.</option>
					    </select>
					    <label for="salute">Salutation</label>
					</div>
					<div class="input-field col s6">
						<input id="name"name="name" type="text" class="validate" value="<?php echo $_SESSION['name']; ?>">
						<label for="name">Full Name</label>
					</div>
			    </div>
			  
				<div class="row">
					<div class="input-field col s6">
						<select id="sex" name="sex">
					       	<option value="" disabled selected>Choose your option</option>
					        <option value="M">Male</option>
					        <option value="F">Female</option>
					        <option value="O">Others</option>
					    </select>
					    <label for="sex">Sex</label>
					</div>
					<div class="input-field col s6">
						<input id="fname" name="fname" type="text" class="validate">
						<label for="fname">Father's Name</label>
					</div>
				</div>
			  
			    <div class="row">
					<div class="input-field col s6">
						<input id="email" name="email" type="email" class="validate"  value="<?php echo $_SESSION['email']; ?>">
						<label for="email">Email</label>
					</div>
					<div class="input-field col s6">
						<input id="contact" name="contact" type="text" length="10" class="validate">
						<label for="contact">Contact</label>
					</div>
				</div>
			  
				<div class="row">
					<div class="input-field col s6">
						<input id="dob" name="dob" type="date" class="datepicker">
						<label for="dob">Date of Birth</label>
					</div>
					<div class="input-field col s6">
						<input id="city" name="city" type="text" class="validate">
						<label for="city">City</label>
					</div>
				</div>

			    <div class="row">
				    <div class="file-field input-field">
				      	<div class="btn">
					        <span>Upload profile pic</span>
					        <input type="file">
				      	</div>
				      	<div class="file-path-wrapper">
				        	<input class="file-path validate" type="text">
				      	</div>
				    </div>
			    </div>
			    <br>
			    <br>
			    <!-- department details -->
				<div class="row">
					<h2 class="profile-head">Department Details:<h2>
				</div>
				
				<div class="row">
					<div class="input-field col s6">
						<input id="dept" name="dept" type="text" class="validate"  value="<?php echo $_SESSION['dept']; ?>">
						<label for="dept">Department Name</label>
					</div>
					<div class="input-field col s6">
						<input id="dept_code" name="dept_code" type="text" class="validate"  value="<?php echo $_SESSION['d_code']; ?>">
						<label for="dept_code">Department Code</label>
					</div>
				</div>
				
				<div class="row">
					<div class="input-field col s6">
						<select id="no_year" name="no_year">
					       	<option value="" disabled selected>Choose your option</option>
					        <option value="1">1</option>
					        <option value="2">2</option>
					        <option value="3">3</option>
					        <option value="4">4</option>
					        <option value="5">5</option>
					    </select>
					    <label for="no_year">Minimum no. of year</label>
					</div>
					<div class="input-field col s6">
						<input id="j_date" name="j_date" type="date" class="datepicker">
						<label for="j_date">Your Joining date</label>
					</div>
				</div>
				
				<div class="row">
					<div class="input-field col s6">
						<select id="estb_year" name="estb_year">
					       	
					    </select>
						<label for="estb_year">Establishment Year</label>
				    </div>
				    <div class="input-field col s6">
						<select multiple id="select_des" name="select_des">
					       	<option value="" disabled selected>Choose your option</option>
					        <option value="Student">Student</option>
					        <option value="Faculty">Faculty</option>
					        <option value="HOD">HOD</option>
					        <option id="others_des" value="">Others</option>
					    </select>
					    
					    <label for="select_des">Designations in your department</label>
					    
					    <div class="row" id="create_des_div" style="display:none">
							<div class="input-field col s6">
								<input id="new_des" name="new_des" type="text" class="validate">
								<label for="new_des">Add Designation: </label>
							</div>
							<div class="input-field col s3">
						    	<a class="waves-effect waves-light btn" onclick='create_new_des()'>Add to list</a>
						    </div>
							<div class="input-field col s3">
						    	<a class="waves-effect waves-light btn" onclick='cancel_new_des()'>Cancel</a>
						    </div>
						</div>
				    </div>
				</div>
				
				<div class="row">
					<div class="input-field col s12">
						<textarea id="details" name="details" class="materialize-textarea" length="500"></textarea>
						<label for="details">Description about the department</label>
					</div>
				</div>
				
				<br><br>
				<div class="row">
					<h2 class="profile-head">Security:<h2>
				</div>
				<div class="row">
					<div class="input-field col s6">
						<input id="password" name="password" type="password" class="validate">
						<label for="password">Password</label>
					</div>
					<div class="input-field col s6">
						<input id="re_password" name="re_password" type="password" class="validate">
						<label for="re_password">Retype Password</label>
					</div>
				</div>
			  
				
				<div class="row" style="text-align:center">
					<button class="btn-large waves-effect waves-light" type="submit" name="action">Setup My Account
						<i class="material-icons right">send</i>
					</button>
				</div>
			</form>
		</div>
    
    <footer class="page-footer teal">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text">Company Bio</h5>
                    <p class="grey-text text-lighten-4">We are a team of college students working on this project like it's our full time job. Any amount would help support and continue development on this project and is greatly appreciated.</p>
                </div>
                <div class="col l3 s12">
                    <h5 class="white-text">Settings</h5>
                    <ul>
                        <li><a class="white-text" href="#!">Link 1</a></li>
                        <li><a class="white-text" href="#!">Link 2</a></li>
                        <li><a class="white-text" href="#!">Link 3</a></li>
                        <li><a class="white-text" href="#!">Link 4</a></li>
                    </ul>
                </div>
                <div class="col l3 s12">
                    <h5 class="white-text">Connect</h5>
                    <ul>
                        <li><a class="white-text" href="#!">Link 1</a></li>
                        <li><a class="white-text" href="#!">Link 2</a></li>
                        <li><a class="white-text" href="#!">Link 3</a></li>
                        <li><a class="white-text" href="#!">Link 4</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
            </div>
        </div>
    </footer>


    <!--  Scripts-->
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="js/materialize.js"></script>
    <script src="js/init.js"></script>

</body>
</html>

<?php 
	if(!empty(filter_input(INPUT_GET, 'error'))){
		$error=filter_input(INPUT_GET, 'error');
		echo '<script type="text/javascript"> $("#error_chip").append("We are unable to create your account, Error:'.$error.'."); $("#error_chip").show();</script>';
		//unset(filter_input(INPUT_GET, 'created'));
	}
?>