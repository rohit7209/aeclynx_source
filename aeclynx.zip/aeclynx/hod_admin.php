<!DOCTYPE html>
<html lang="en">
    <!--head-->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
    <title>Notifications & Updates</title>
    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    
    <script type="text/javascript" src="jquery-2.2.2.min.js"></script>	
    <script type="text/javascript" src="update_hod.js"></script>
</head>

<body>
    <!--navigation links-->
    <nav class="white" role="navigation">
        <div class="nav-wrapper container" style="width:100%">
            <a id="logo-container" href="#" class="brand-logo">AEC Lynx</a>
            <ul class="right hide-on-med-and-down">
                <li><a href="index.php">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>

            <ul id="nav-mobile" class="side-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
            <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
        </div>
    </nav>
    
    
    <!--error chip-->
    <div class="row" style="text-align: center;margin-top: 20px">    
        <div id="error_chip" class="chip" style="display:none">
            <i class="material-icons">close</i>
        </div>
    </div>    

    
        
    <!--admin panel-->
    <div class="row" id="admin_panel">    
        <div class="col s12" style="text-align: center">
            <p class="input-field col s4">
                <input name="group1" value="" onclick="show_element('bulk_selector');hide_element('individual_selector');hide_element('overview_panel');" type="radio" id="t1" />
                <label for="t1">Create Accounts in Bulk</label>
            </p>
            <p class="input-field col s4">
                <input name="group1" value="" onclick="show_element('individual_selector');hide_element('bulk_selector');hide_element('overview_panel');" type="radio" id="t3" />
                <label for="t3">Create Accounts individually </label>
            </p>
            <p class="input-field col s4">
                <input name="group1" value="" onclick="show_element('overview_panel');hide_element('bulk_selector');hide_element('individual_selector');" type="radio" id="t2" />
                <label for="t2">Overview on existing Dept/Personnel</label>
            </p>
            
            <br>
            <br>
            <br>
            <br>

            <div class="input-field col s12" id="bulk_selector" style="display: none">
                <a class='dropdown-button btn' href='#' id="selected" data-activates='bulk_dropdown'>Select Designation</a>

                <ul id='bulk_dropdown' class='dropdown-content'>
                    <li><a href="#!" onclick="show_element('bulk_student_form');hide_element('bulk_faculty_form')">Students Account</a></li>
                    <li><a href="#!" onclick="show_element('bulk_faculty_form');hide_element('bulk_student_form')">Faculties Account</a></li>
                </ul>
                
                <!--ajax_loader-->
                <div class="row" id="loading" style="display:none">
                    <img src="loader.gif">
                </div>


                <!--bulk student's account form-->
                <div class="section" id="bulk_student_form" style="display:none;text-align: center">
                    <form method="post" action="function_handler.php?register_bulk_students=true">
	                    <div class="row">
	                        <div class="input-field col s6">
	                            <select id="year" name="year">
							       	<option value="" disabled selected>Choose your option</option>
						    	</select>
							    <label for="year">Current Year</label>
	                        </div>
	                        <div class="input-field col s6">
	                            <select id="batch" name="batch">
							       	<option value="" disabled selected>Choose your option</option>
							        <option value="B11">Batch B11</option>
							        <option value="B12">Batch B12</option>
							        <option value="B21">Batch B21</option>
							        <option value="B22">Batch B22</option>
						    	</select>
							    <label for="batch">Batch (according to the lab)</label>
	                        </div>
	                    </div>
                        
                    <div class="row">
					    <div class="file-field input-field">
					      	<div class="btn">
						        <span>Upload Excel Sheet</span>
						        <input type="file" name="dir" id="dir">
					      	</div>
					      	<div class="file-path-wrapper">
					        	<input class="file-path validate" type="text">
					      	</div>
					    </div>
				    </div>
					    
	                   	<div class="row" style="text-align:center">
	                       	<button class="btn-large waves-effect waves-light" type="submit" name="action">Create Accounts
	                            <i class="material-icons right">send</i>
	                       	</button>
	                   	</div>
                   	</form>
                </div>


                <!--bulk faculty account form-->
                <div class="input-field col s12" id="bulk_faculty_form" style="display:none;text-align: center">
                    <div class="row">
					    <div class="file-field input-field">
					      	<div class="btn">
						        <span>Upload Excel Sheet</span>
						        <input type="file">
					      	</div>
					      	<div class="file-path-wrapper">
					        	<input class="file-path validate" type="text">
					      	</div>
					    </div>
				    </div>
				    <div class="row" style="text-align:center">
                       	<button class="btn-large waves-effect waves-light" type="" name="action">Create Accounts
                            <i class="material-icons right">send</i>
                       	</button>
                   	</div>
                </div>
            </div>
            
            <div class="input-field col s12" id="individual_selector" style="display: none">
                <a class='dropdown-button btn' href='#' id="selected" data-activates='individual_dropdown'>Select Designation</a>

                <ul id='individual_dropdown' class='dropdown-content'>
                    <li><a href="#!" onclick="">Students Account</a></li>
                    <li><a href="#!" onclick="">Faculties Account</a></li>
                </ul>
                
                <!--ajax_loader-->
                <div class="row" id="loading" style="display:none">
                    <img src="loader.gif">
                </div>
            </div>
            
            
            <!--overview search panel-->
            <div id="overview_panel" style="display:none">
            <div class="section col s12">
                <div class="section col s6">            
                    <form method="post" action="#" class="col s12">
                    
                    <div class="input-field col s12">
                        <select id="dept_chooser" class="browser-default" onclick="">
                            <option value="" disabled selected>Select Department/Principal</option>
                        </select>
                        <div class="row" id="loading_dept" style="display:none">
                            <img src="loader.gif">
                        </div>
                    </div>
                    
                    
                    <div class="input-field col s12">
                        <select id="des_chooser" class="browser-default">
                            <option value="" disabled selected>Select Designation</option>
                        </select>
                        <div class="row" id="loading_des" style="display:none">
                            <img src="loader.gif">
                        </div>
                    </div>
                    
                    <div class="input-field col s12" >
                        <div id="year_chooser" style="display:none">
	                        <input name="group2" type="radio" id="yr1" />
	      					<label for="yr1">Red</label>
                        </div>
                        <div class="row" id="loading_year" style="display:none">
                            <img src="loader.gif">
                        </div>
                    </div>
                        
                    
                    <div class="input-field col s12">
                        <select id="name_chooser" class="browser-default">
                            <option value="" disabled selected>Select Person</option>
                        </select>
                        <div class="row" id="loading_name" style="display:none">
                            <img src="loader.gif">
                        </div>
                    </div>
                        
                    <div class="row" id="batch_selector" style="display:none">
                        <img src="loader.gif">
                    </div>
                    
                    <div class="input-field col s12">
                        <a class='dropdown-button btn-large' href='#' id="dfdf" data-activates='dropdown2'>Select Preference</a>
                        <ul id='dropdown2' class='dropdown-content'>
                            <li><a href="#!" onclick="">All users</a></li>
                            <li><a href="#!" onclick="">Active users</a></li>
                            <li><a href="#!" onclick="">Pending users</a></li>
                            <li><a href="#!" onclick="">Restricted users</a></li>
                        </ul>
                    </div>
                </form>
                </div>
                
                <div class="section col s6">
                    <div class="input-field col s12">
                        <a class="waves-effect waves-light btn-large" onclick="load_quered_users(1)" style="background: transparent;color:grey;width:100%"><i class="material-icons left green-text">account_circle</i>List All Active Users</a>
                    </div>
                    <div class="input-field col s12">
                        <a class="waves-effect waves-light btn-large" onclick="load_quered_users(2)" style="background: transparent;color:grey;width:100%"><i class="material-icons left yellow-text">account_circle</i>List All Pending Users</a>
                    </div>
                    <div class="input-field col s12">
                        <a class="waves-effect waves-light btn-large" onclick="load_quered_users(3)" style="background: transparent;color:grey;width:100%"><i class="material-icons left red-text">account_circle</i>List All Restricted Users</a>
                    </div>
                    <div class="input-field col s12">
                        <a class="waves-effect waves-light btn-large" onclick="load_quered_users(4)" style="background: transparent;color:grey;width:100%"><i class="material-icons left black-text">account_circle</i>List All Deleted Users</a>
                    </div>
                </div>
            </div>
            
            <!--result panel-->
            <div class="row col s12" id="result_panel" style="display: none;text-align: left">
                <div class="col s12 m12">
                    <div class="card" style="box-shadow:none">
                    <div class="card-content black-text">
                        <span class="card-title black-text">Profile list</span>
                        
                        <!--result list-->
                        <ul class="collapsible popout" id="results" data-collapsible="accordion">
                            
                        </ul>
                        
                        <!--pagination-->
                        <ul class="pagination align-left" id="page_counter" style="">
                            
                        </ul>
                    </div>
                        
                    <div class="row" id="searching" style="width:100%;text-align:center;display:none">
                        <img src="preloader1.gif">
                    </div>
                    <div class="card-action">
                      <a href="#">Close</a>
                    </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
    
    
    <!-- <form method="post" action="function_handler.php?create_dept_account=true" class="col s12">
                        <div class="row">
                            <div class="input-field col s6">
                                <input id="dept_name" name="dept_name" type="text" required class="validate">
                                <label for="dept_name">Department Name</label>
                            </div>
                            <div class="input-field col s6">
                                <input id="code" name="code" type="text" required class="validate">
                                <label for="code">Dept Code</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s6">
                                <input id="name" name="name" type="text" required class="validate">
                                <label for="name">HOD Name</label>
                            </div>
                            <div class="input-field col s6">
                                <input id="email" name="email" type="email" required class="validate">
                                <label for="email">Email of HOD</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <textarea id="msg" name="msg" class="materialize-textarea" length="120"></textarea>
                                <label for="msg">Message to HOD</label>
                            </div>
                        </div>
                        <div class="row" style="text-align:center">
                            <button class="btn-large waves-effect waves-light" type="" name="action">Create Dept & HOD
                                <i class="material-icons right">send</i>
                            </button>
                        </div>
                    </form> -->
    
    <!-- <form method="post" action="function_handler.php?create_staff_account=true" class="col s12">
                        <div class="row">
                            <div class="input-field col s6">
                                <input id="name" name="name" type="text" required class="validate">
                                <label for="name">Name</label>
                            </div>
                            <div class="input-field col s6">
                                <input id="email" name="email" type="email" required class="validate">
                                <label for="email">Email</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s6">
                                <input id="des" name="des" type="text" required class="validate">
                                <label for="des">Designation</label>
                            </div>
                            <div class="input-field col s6">
                                <input id="dept" name="dept" type="text" required class="validate">
                                <label for="dept">Department</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <textarea id="msg" name="msg" class="materialize-textarea" length="120"></textarea>
                                <label for="msg">Any Message</label>
                            </div>
                        </div>
                        <div class="row" style="text-align:center">
                            <button class="btn-large waves-effect waves-light" type="" name="action">Create Account
                                <i class="material-icons right">send</i>
                            </button>
                        </div>
                    </form> -->
    
    <div style="height:300px;width:100%"></div>
    
    <!--footer-->
    <footer class="page-footer teal">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text">Company Bio</h5>
                    <p class="grey-text text-lighten-4">We are a team of college students working on this project like it's our full time job. Any amount would help support and continue development on this project and is greatly appreciated.</p>
                </div>
                <div class="col l3 s12">
                    <h5 class="white-text">Settings</h5>
                    <ul>
                        <li><a class="white-text" href="#!">Link 1</a></li>
                        <li><a class="white-text" href="#!">Link 2</a></li>
                        <li><a class="white-text" href="#!">Link 3</a></li>
                        <li><a class="white-text" href="#!">Link 4</a></li>
                    </ul>
                </div>
                <div class="col l3 s12">
                    <h5 class="white-text">Connect</h5>
                    <ul>
                        <li><a class="white-text" href="#!">Link 1</a></li>
                        <li><a class="white-text" href="#!">Link 2</a></li>
                        <li><a class="white-text" href="#!">Link 3</a></li>
                        <li><a class="white-text" href="#!">Link 4</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
            </div>
        </div>
    </footer>


    <!--  Scripts-->
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="js/materialize.js"></script>
    <script src="js/init.js"></script>

</body>
</html>

<?php
if(!empty(filter_input(INPUT_GET, 'created'))){
    $name=filter_input(INPUT_GET, 'created');
    $des=filter_input(INPUT_GET, 'des');
    echo '<script type="text/javascript"> $("#error_chip").append("Account of '.$name.' has been created as '.$des.'."); $("#error_chip").show();</script>';
    //unset(filter_input(INPUT_GET, 'created'));
}elseif(!empty(filter_input(INPUT_GET, 'error'))){
    $name=filter_input(INPUT_GET, 'name');
    $des=filter_input(INPUT_GET, 'des');
    $error=filter_input(INPUT_GET, 'error');
    echo '<script type="text/javascript"> $("#error_chip").append("Account of '.$name.' has not been created as '.$des.'. Error:: '.$error.'"); $("#error_chip").show();</script>';
    //unset(filter_input(INPUT_GET, 'created'));
}


include 'new_con.php';
$value="<option value='Principal'>Principal</option>";
echo '<script type="text/javascript">$("#dept_chooser").append("'.$value.'");</script>';
$result=mysqli_query($con,"SELECT dept_name from dept_details");
while($row=mysqli_fetch_row($result)){
    $value="<option value='".$row[0]."'>".$row[0]."</option>";
    echo '<script type="text/javascript">$("#dept_chooser").append("'.$value.'");</script>';
}


if(isset($_GET['bulk_error'])){
    
}



?>


<!-- 
                   	<div class="row" style="text-align:center">
				        <a class="btn" data-popup-open="popup-1" href="#">Open Popup #1</a>
						<div class="popup" data-popup="popup-1">
						    <div class="popup-inner">
						        <h2>Wow! This is Awesome! (Popup #1)</h2>
						        <p>Donec in volutpat nisi. In quam lectus, aliquet rhoncus cursus a, congue et arcu. Vestibulum tincidunt neque id nisi pulvinar aliquam. Nulla luctus luctus ipsum at ultricies. Nullam nec velit dui. Nullam sem eros, pulvinar sed pellentesque ac, feugiat et turpis. Donec gravida ipsum cursus massa malesuada tincidunt. Nullam finibus nunc mauris, quis semper neque ultrices in. Ut ac risus eget eros imperdiet posuere nec eu lectus.</p>
						        <p><a data-popup-close="popup-1" href="#">Close</a></p>
						        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
						    </div>
						</div>
					</div>				     -->