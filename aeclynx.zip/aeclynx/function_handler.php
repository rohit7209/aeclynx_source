<?php
//error_reporting(0);
include 'base.php';

if(isset($_GET['check_principal'])){
    check_principal($con);
}
elseif(isset($_GET['create_account'])){
    create_principal_account($con);
}
elseif(isset($_GET['create_dept_account'])){
    create_dept_account($con);
}
elseif(isset($_GET['create_staff_account'])){
    create_staff_account($con);
}
elseif(isset($_GET['load_dean_quered_profile'])){
    load_dean_quered_profile($con);
}
elseif(isset($_GET['get_profile_pic'])){
    get_profile_pic($con);
}
elseif(isset($_GET['get_pagination_number'])){
    get_pagination_number($con);
}
elseif(isset($_GET['get_designations'])){
    get_designations($con);
}
elseif(isset($_GET['get_names'])){
    get_names($con);
}
elseif(isset($_GET['get_name_details'])){
    get_name_details($con);
}
elseif(isset($_GET['get_years'])){
	get_years($con);
}
elseif(isset($_GET['activate_hod'])){
	activate_hod($con);
}
elseif(isset($_GET['create_hod_account'])){
	create_hod_account($con);
}
elseif(isset($_GET['register_bulk_students'])){
	register_bulk_students($con);
}



function get_years($con){
	if(isset($_GET['dept'])){
		$dept=filter_input(INPUT_GET, 'dept');
	}else{
		$dept=$_SESSION['dept'];
	}
	
	$stmt="select no_year from dept_details where dept_name='".$dept."'";
	$result=mysqli_query($con, $stmt);
	while($row=mysqli_fetch_row($result)){
		echo $row[0];
	}
}



function get_profile_pic($con){
    $user_id=filter_input(INPUT_GET, 'user_id');
    $stmt="select profile_pic from active_users where user_id='".$user_id."'";
    $result=mysqli_query($con, $stmt);
    while($row=mysqli_fetch_row($result)){
        echo $row[0];
    }
}

function get_designations($con){
    $dept=  filter_input(INPUT_GET, 'dept');
    $result=  mysqli_query($con, "SELECT des from dept_details where dept_name='".$dept."'");
    while($row=  mysqli_fetch_row($result)){
        $val=$row[0];
    }
    echo $val;
}

function get_names($con){
    $dept=filter_input(INPUT_GET, 'dept');
    $des=filter_input(INPUT_GET, 'des');
    
    if($des=='Faculty'){
        $result=mysqli_query($con, "SELECT name from fac_users_details where dept='".$dept."' AND des='".$des."'");
    }else{
        $result=mysqli_query($con, "SELECT name from adm_users_details where dept='".$dept."' AND des='".$des."'");
    }
    $i=0;
    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_row($result)){
            if($i>0){
                $val=$val.'/'.$row[0];
            }else{
                $val=$row[0];
            }
            $i++;
        }
        echo $val;
    }
}

function get_name_details($con){
    $dept=filter_input(INPUT_GET, 'dept');
    $des=filter_input(INPUT_GET, 'des');
    $name=filter_input(INPUT_GET, 'name');
    
    if($des=='Faculty'){
        $table='fac_users_details';
    }else{
        $table='adm_users_details';
    }
    
    if(!isset($_GET['name']) || $name=='All'){
    	$stmt="select * from ".$table." where des = '".$des."' AND dept = '".$dept."'";
    }else{
    	echo 'fgtr	';
    	$stmt="select * from ".$table." where des = '".$des."' AND dept = '".$dept."' AND name='".$name."'";
    }
    
    
    $result=  mysqli_query($con, $stmt);
    $i=0;
    $str='';
    while($row=mysqli_fetch_row($result)){
        if($i>0){
            $str=$str.'/=/';
        }
        $j=0;
        foreach($row as $col){
            if($j>0){
                $str=$str.'/+/'.$col;
            }else{
                $str=$str.$col;
            }
            $j++;
        }
        $i++;
    }
    
    echo $str;
}

function load_dean_quered_profile($con){
    $table=filter_input(INPUT_GET, 'id');
    $stmt="select * from ".$table." where NOT(des = 'Student' OR des = 'Faculty')"; /**/
    $result=  mysqli_query($con, $stmt);
    $i=0;
    $str='';
    while($row=mysqli_fetch_row($result)){
        if($i>0){
            $str=$str.'/=/';
        }
        $j=0;
        foreach($row as $col){
            if($j>0){
                $str=$str.'/+/'.$col;
            }else{
                $str=$str.$col;
            }
            $j++;
        }
        $i++;
    }
    echo $str;
}



function check_principal($con){
    $stmt=  "SELECT des from adm_users_details where des='Principal'";
    $result=mysqli_query($con, $stmt);
    if(mysqli_num_rows($result)>0){
        echo 'N';
    }else{
        $result=mysqli_query($con, "SELECT des from queued_users where des='Principal'");
        if(mysqli_num_rows($result)>0){
            echo 'N';
        }else{
            //echo "error:".  mysqli_error($con);
            echo 'Y';
        }
    }
}



function is_email_free($con, $email){
    $result=mysqli_query($con,"SELECT * from active_users where email='".$email."'");
    if(mysqli_num_rows($result)==0){
        $result=mysqli_query($con,"SELECT * from queued_users where email='".$email."'");
        if(mysqli_num_rows($result)==0){
            return 1;
        }else{
            return 0;
        }
    }else{
        return 0;
    }
}



function new_user_id($con){
    $result=mysqli_query($con, "SELECT top_id from adm_users");
    while($row=mysqli_fetch_row($result)){
        $top_id=$row[0];
    }
    if($top_id>999){
    	$top_id=100;
    }
    $set_top_id=$top_id+1;
    mysqli_query($con, "UPDATE adm_users SET top_id = '".$set_top_id."'");

    date_default_timezone_set("Asia/Kolkata");
    $yr=  date("Y");
    $mn=  date("m");
    $user_id="ADM".substr($yr,2).$mn.$top_id;
    return $user_id;
}

function student_user_id($con,$dept, $year, $batch){
	$result=mysqli_query($con, "SELECT top_id from stu_users");
	while($row=mysqli_fetch_row($result)){
		$top_id=$row[0];
	}
	if($top_id>9999){
    	$top_id=1000;
    }
	$set_top_id=$top_id+1;
    mysqli_query($con, "UPDATE stu_users SET top_id = '".$set_top_id."'");
    
	$result=mysqli_query($con, "SELECT dept_code from dept_details where dept_name='".$dept."'");
	while($row=mysqli_fetch_row($result)){
		$d_code=$row[0];
	}
	
	
	date_default_timezone_set("Asia/Kolkata");
	$mn=date("m");
	echo $mn;
	if($mn>=07){
		$yr=substr(date("Y")-$year+1,2);
	}else{
		$yr=substr(date("Y")-$year,2);
	}
	$user_id=$d_code.$batch.$yr.$top_id;
	return $user_id;
}

function create_staff_account($con){
    $email=filter_input(INPUT_POST, 'email');
    if(is_email_free($con, $email)==1){
        $name=filter_input(INPUT_POST, 'name');
        $msg=filter_input(INPUT_POST, 'msg');
        $des=filter_input(INPUT_POST, 'des');
        $dept=filter_input(INPUT_POST, 'dept');
        
        $user_id=new_user_id($con);
        
        $password = substr(str_shuffle("012345678901234567890123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);

        $stmt="Insert into queued_users values ('".$user_id."','".$password."','".$name."','".$email."','".$des."','".$dept."')";
        if(mysqli_query($con, $stmt)){
            header("Refresh:0;url=home.php?created=".$name."&des=".$des."&load_dean_admin_portal=true");
        }else{
            $error=mysqli_error($con);
            header("Refresh:0;url=home.php?error=".$error."&name=".$_POST['name']."&des=".$des."&load_dean_admin_portal=true");
        }
    }else{
        $error="email is already registered with another user";
        header("Refresh:0;url=home.php?error=".$error."&name=".$_POST['name']."&des=".$des."&load_dean_admin_portal=true");
    }
}



function create_principal_account($con){
    $email=filter_input(INPUT_POST, 'email');
    if(is_email_free($con, $email)==1){
        $msg=$_POST['msg'];
        $name=filter_input(INPUT_POST, 'name');
        $user_id=new_user_id($con);
        $password = substr(str_shuffle("012345678901234567890123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);

        $stmt="Insert into queued_users values ('".$user_id."','".$password."','".$name."','".$email."','Principal','AEC')";
        if(mysqli_query($con, $stmt)){
            header("Refresh:0;url=home.php?created=".$_POST['name']."&des=Principal&load_dean_admin_portal=true");
        }else{
            $error=mysqli_errno($con);
            header("Refresh:0;url=home.php?error=".$error."&name=".$name."&des=Principal&load_dean_admin_portal=true");
        }
    }else{
        $error="email is already registered with another user";
        header("Refresh:0;url=home.php?error=".$error."&name=".$name."&des=Principal&load_dean_admin_portal=true");
    }
}


function create_dept_account($con){
    $email=filter_input(INPUT_POST, 'email');
    $name=filter_input(INPUT_POST, 'name');
    $msg=filter_input(INPUT_POST, 'msg');
    $des="HOD";
    $dept_code=filter_input(INPUT_POST, 'code');
    $dept_name=filter_input(INPUT_POST, 'dept_name');
    
    if(is_email_free($con, $email)==1){
        $result=mysqli_query($con,"SELECT dept_name from dept_details where dept_name='".$dept_name."' or dept_code='".$dept_code."'");
        if(mysqli_num_rows($result)==0){

            $user_id=new_user_id($con);
            $password = substr(str_shuffle("012345678901234567890123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);

            $token=substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 75).$user_id.substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 75);
            
            $stmt="Insert into queued_users values ('".$user_id."','".$password."','".$name."','".$email."','".$des."','".$dept_name."','".$token."')";
            $stmt1="Insert into dept_details values ('".$dept_name."','".$dept_code."','NA','".$name."','HOD/Faculty/Student','4','NA')";

            if(!mysqli_query($con, $stmt) || !mysqli_query($con, $stmt1)){
                echo 'error:'.mysqli_error($con);
                header("Refresh:0;url=home.php?error=".mysqli_error($con)."&name=".$_POST['name']."&des=HOD&load_dean_admin_portal=true");
            }else{
                header("Refresh:0;url=home.php?created=".$name."&des=".$des."&load_dean_admin_portal=true");
            }
        }else{
            $error="Department already exists";
            header("Refresh:0;url=home.php?error=".$error."&name=".$name."&des=HOD&load_dean_admin_portal=true");
        }
    }else{
        $error="email is already registered with another user";
        header("Refresh:0;url=home.php?error=".$error."&name=".$name."&des=HOD&load_dean_admin_portal=true");
    }
}

function activate_hod($con){
	$token=$_GET['token'];
	$result=mysqli_query($con,"Select * from queued_users where token='".$token."'");
	if($result){
		while($row=mysqli_fetch_row($result)){
			$_SESSION['name']=$row[2];
			$_SESSION['logged_in']=1;
            $_SESSION['username']=$row[0];
            $_SESSION['dept']=$row[5];
            $_SESSION['des']=$row[4];
            $_SESSION['email']=$row[3];
		}
	}
	
	$result=mysqli_query($con,"Select dept_code from dept_details where dept_name='".$_SESSION['dept']."'");
	if($result){
		while($row=mysqli_fetch_row($result)){
			$_SESSION['d_code']=$row[0];
		}
	}
	
	header("Refresh:0;url=home.php?register_new_hod=true");
}

function create_hod_account($con){
	$name=$_POST['salute']." ".$_POST['name'];;
	$email=$_POST['email'];
	$contact=$_POST['contact'];
	$city=$_POST['city'];
	$fname=$_POST['fname'];
	$sex=$_POST['sex'];
	$dob=$_POST['dob'];
	$password=$_POST['password'];
	
	$dept=$_POST['dept'];
	$dept_code=$_POST['dept_code'];
	$no_year=$_POST['no_year'];
	$j_date=$_POST['j_date'];
	$estb_year=$_POST['estb_year'];
	$select_des=$_POST['select_des'];
	$details=$_POST['details'];
	
	$user_id=$_SESSION['username'];
	$old_dept_code=$_SESSION['d_code'];
	$discharge_date="--";
	$profile="abd";
	
	$stmt="INSERT INTO adm_users_details 
			VALUES ('".$user_id."','".$name."','".$email."','".$j_date."','".$discharge_date."','".$dept."','HOD','".$contact."','".$city."','".$dob."','".$fname."','".$profile."')";

	$stmt1="UPDATE dept_details 
			SET dept_name='".$dept."', dept_code='".$dept_code."', estb_year='".$estb_year."', HOD_name='".$name."', des='".$select_des."', no_year='".$no_year."', description='".$details."'
			WHERE dept_code='".$old_dept_code."'";	
	
	$stmt2="INSERT INTO active_users
			VALUES ('".$user_id."','".$password."','".$email."','".$profile."','adm_users_details')";
	
	
	if($email==$_SESSION['email']){
		$proceed=1;
	}else if(is_email_free($con, $email)==1){
		$proceed=1;
	}else{
		$proceed=0;
	}
	
	if($proceed==1){
		$result=mysqli_query($con,"SELECT dept_name from dept_details where dept_name='".$dept."' or dept_code='".$dept_code."'");
		
		if($dept==$_SESSION['dept'] || $dept_code==$_SESSION['dept_code']){
			$proceed=1;
		}else if(mysqli_num_rows($result)==0){
			$proceed=1;
		}else{
			$proceed=0;
		}
		if($proceed==1){
			if(!mysqli_query($con, $stmt) || !mysqli_query($con, $stmt1) || !mysqli_query($con, $stmt2)){
				echo 'error:'.mysqli_error($con);
			}else{
				header("Refresh:0;url=index.php");
			}
		}else{
			$error="Department already exists";
			header("Refresh:0;url=register_hod.php?error=".$error);
		}
	}else{
		$error="email is already registered with another user";
		header("Refresh:0;url=register_hod.php?error=".$error);
	}
}



function register_bulk_students($con){
	
	require_once('PHPExcel/IOFactory.php');
	require_once('PHPExcel.php');
	
	$dept=$_SESSION['dept'];
	$batch=$_POST['batch'];
	$year=$_POST['year'];

	echo 'highest row::';
	
	$sheet_path=$_POST['dir'];

	$obj_excel = PHPExcel_IOFactory::load($sheet_path);
	$get_sheets = $obj_excel->getAllSheets();

	$failed_name='';
	$failed_roll='';
	$failed_email='';
	$failed_error='';
	$i=0;
		
	foreach($get_sheets as $sheet){
		$highestRow=$sheet->getHighestRow();
		$highestColumn=$sheet->getHighestColumn();
		
		for($row=1;$row<=$highestRow;$row++){
			$rowData = $sheet->rangeToArray('A'.$row.':'.$highestColumn.$row,NULL,TRUE,FALSE);
			$roll=$rowData[0][0];
			$name=$rowData[0][1];
			$email=$rowData[0][2];
			$des="Student";
			
			if(is_email_free($con, $email)){
				$user_id=student_user_id($con, $dept, $year, $batch);
				$password = substr(str_shuffle("012345678901234567890123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);
				$token=substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 75).$user_id.substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 75);
				
				$sql="INSERT INTO queued_users VALUES ('$user_id','$password','$name','$email','$des','$dept','$token','$roll')";
				
				if(!mysqli_query($con,$sql)){
					if($i<1){
						$failed_name=$name;
						$failed_roll=$roll;
						$failed_email=$email;
						$failed_error=mysqli_error($con);
					}else{
						$failed_name=$failed_name.'*/*'.$name;
						$failed_roll=$failed_roll.'*/*'.$roll;
						$failed_email=$failed_email.'*/*'.$email;
						$failed_error=$failed_error.'*/*'.mysqli_error($con);
					}
					$i++;
				}
			}else{
                            if($i<1){
                                $failed_name=$name;
                                $failed_roll=$roll;
                                $failed_email=$email;
                                $failed_error="Email is already registered";
                            }else{
                                $failed_name=$failed_name.'*/*'.$name;
                                $failed_roll=$failed_roll.'*/*'.$roll;
                                $failed_email=$failed_email.'*/*'.$email;
                                $failed_error=$failed_error.'*/*'."Email is already registered";
                            }
                            $i++;
			}
		}
	}
	echo $failed_name."</br>";
	echo $failed_roll."</br>";
	echo $failed_email."</br>";
	echo $failed_error."</br>";
}

/*
	mysqli_query($con, $stmt);
	echo 'error1::'.mysqli_error($con);
	mysqli_query($con, $stmt1);
	echo 'error2::'.mysqli_error($con);
	
	
	echo 'done';
	
	*/