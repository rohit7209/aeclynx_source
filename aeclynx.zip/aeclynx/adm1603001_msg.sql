-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2016 at 06:34 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `aeclynx`
--

-- --------------------------------------------------------

--
-- Table structure for table `adm1603001_msg`
--

CREATE TABLE IF NOT EXISTS `adm1603001_msg` (
  `time` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `sender` varchar(255) NOT NULL,
  `reciever` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `attch_loc` varchar(255) NOT NULL,
  `opened` varchar(255) NOT NULL,
  `ntf_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adm1603001_msg`
--

INSERT INTO `adm1603001_msg` (`time`, `date`, `sender`, `reciever`, `title`, `content`, `attch_loc`, `opened`, `ntf_id`) VALUES
('11:40:00 PM', '12/08/2016', 'The HOD (Dr. Ghi dey)', '--', 'pqr', 'hehehe how jvbjhdsb sbsjdb kvjbdb jbvjh sadl shits are not happening on in this college', 'NA', 'T', 'msg210'),
('10:12:00 AM', '12/12/2016', 'The Dean (Mr. R. K. Dhar)', '--', 'Abcd', 'what the hell is going on in this college', 'NA', 'T', 'msg100'),
('08:40:00 PM', '12/02/2016', 'The Principal (Dr. Abc dey)', '--', 'Xyz', 'why the shits are n\r\not happening\r\non in this college', 'NA', 'T', 'msg110');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adm1603001_msg`
--
ALTER TABLE `adm1603001_msg`
  ADD PRIMARY KEY (`content`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
