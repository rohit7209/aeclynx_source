<?php
error_reporting(0);
include 'base.php';

if(isset($_GET['load_dean'])){
    load_dean();
}elseif(isset($_GET['load_hod'])){
    load_hod();
}elseif(isset($_GET['load_fac'])){
    load_fac();
}elseif(isset($_GET['load_stf'])){
    load_stf();
}elseif(isset($_GET['load_stu'])){
    load_stu();
}elseif(isset($_GET['load_notifications'])){
    load_ntf();
}elseif(isset($_GET['load_dean_admin_portal'])){
    load_dean_admin();
}elseif(isset($_GET['register_new_hod'])){
	register_new_hod();
}elseif(isset($_GET['load_hod_admin_portal'])){
    load_hod_admin();
}


function register_new_hod(){
	include 'register_hod.php';
}

function load_hod(){
    include 'hod.php';
}

function load_dean(){
    include 'dean.php';
}

function load_ntf(){
    include 'notifications.php';
}

function load_dean_admin(){
	include 'dean_admin.php';
}

function load_hod_admin(){
    include 'hod_admin.php';
}
?>