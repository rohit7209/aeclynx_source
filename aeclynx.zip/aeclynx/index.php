<?php include "base.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"></meta>	
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
    <title>Parallax Template - Materialize</title>
    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<?php
    $username=filter_input(INPUT_POST, 'username');
    $password=filter_input(INPUT_POST, 'password');
    if(!empty($_SESSION['logged_in']) && !empty($_SESSION['username'])){
            header("Refresh:0; url=login.php");
    }
    elseif(!empty($username) && !empty($password)){
        $stmt="select * from active_users where user_id='".$username."' and password='".$password."'";
        $result= mysqli_query($con, $stmt);
        if(mysqli_num_rows($result)==1){
            while($row=mysqli_fetch_row($result)){
                $_SESSION['profile_pic']=$row[3];
                $_SESSION['data_table']=$row[4];
            }
            $stmt="select * from ".$_SESSION['data_table']." where user_id='".$username."'";
            $result= mysqli_query($con, $stmt);
            $_SESSION['logged_in']=1;
            while($row=mysqli_fetch_row($result)){
                $_SESSION['username']=$row[0];
                $_SESSION['name']=$row[1];
                $_SESSION['dept']=$row[5];
                $_SESSION['des']=$row[6];
                $_SESSION['email']=$row[2];
                $_SESSION['contact']=$row[7];
                $_SESSION['city']=$row[8];
                $_SESSION['enrol_date']=$row[3];
            }
            echo "<h1>You are logged in.</h1>";
            echo "<p>We are now redirecting you to the member area.</p>";
            header("Refresh:0; url=login.php");
        }elseif(mysqli_num_rows($result)>1){
            echo'<h1>Error:</h1></br> multiple users with same credentials</br>Report to <a href="">admin</a>.';
        }else{
            echo "<h1>Error</h1>";
            echo "<p>Sorry, your account could not be found. Please <a href=\"index.php\">click here to try again</a>.</p>";
        }
    }
    else
    {
	?>

<body>
    <!--navigation links-->
<div style="background-image: url('background4.jpg'); background-repeat: no-repeat;background-size: 100% 100%">
    <nav class="white" role="navigation">
        <div class="nav-wrapper container" style="width:100%">
            <a id="logo-container" href="#" class="brand-logo">AEC Lynx</a>
            <ul class="right hide-on-med-and-down">
                <li><a href="#">About</a></li>
            </ul>

            <ul id="nav-mobile" class="side-nav">
              <li><a href="#">About</a></li>
            </ul>
            <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
        </div>
    </nav>
    
    <div class="row">
        <div class="card s12 m4">
            <form method="post" action="index.php" class="col s4" style="float:right;min-width: 300px">
                <div class="row">
                    <div class="input-field col s12">
                        <i class="material-icons prefix white-text">account_circle</i>
                        <input id="username" name="username" type="text" class="validate" style="border-color: white" >
                        <label style="color:white" for="first_name">User Id/Email</label>
                    </div>
                    <div class="input-field col s12">
                        <i class="material-icons white-text prefix">lock</i>
                        <input id="password" name="password" type="password" class="validate"  style="border-color: white">
                        <label style="color:white" for="last_name">Password</label>
                    </div>
                </div>

                <div class="row" style="text-align:center">
                    <button class="btn waves-effect waves-light" style="box-shadow: none;background:transparent;font-weight: bold" type="submit" name="action">LogIn
                        <i class="material-icons right">send</i>
                    </button>
                </div>
            </form>
        </div>
    </div>
    

    <div style="width:100%;height: 400px">
    </div>
</div>
    
    
    <footer class="page-footer teal">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text">AEC Lynx</h5>
                    <p class="grey-text text-lighten-4">We are a team of college students working on this project like it's our full time job. Any amount would help support and continue development on this project and is greatly appreciated.</p>
                </div>
                <div class="col l3 s12">
                    <h5 class="white-text">Settings</h5>
                    <ul>
                        <li><a class="white-text" href="#!">Link 1</a></li>
                        <li><a class="white-text" href="#!">Link 2</a></li>
                        <li><a class="white-text" href="#!">Link 3</a></li>
                        <li><a class="white-text" href="#!">Link 4</a></li>
                    </ul>
                </div>
                <div class="col l3 s12">
                    <h5 class="white-text">Connect</h5>
                    <ul>
                        <li><a class="white-text" href="#!">Link 1</a></li>
                        <li><a class="white-text" href="#!">Link 2</a></li>
                        <li><a class="white-text" href="#!">Link 3</a></li>
                        <li><a class="white-text" href="#!">Link 4</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
            </div>
        </div>
    </footer>


    <!--  Scripts-->
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="js/materialize.js"></script>
    <script src="js/init.js"></script>

</body>

<?php
    }
?>
</html>
