
$(document).ready(function() {
	$('select').material_select();
	
	//pop-up js
	/*
	$('[data-popup-open]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-open');
        $('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
 
        e.preventDefault();
    });
 
    //----- CLOSE
    $('[data-popup-close]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-close');
        $('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
 
        e.preventDefault();
    });
	*/
	
	$('.datepicker').pickadate({
	    selectMonths: true, // Creates a dropdown to control month
	    selectYears: 15 // Creates a dropdown of 15 years to control year
	});
	       
	$(document).ajaxStart(function () {
        $("#loading").show();
//        $("#searching").show();
    }).ajaxStop(function () {
        $("#loading").hide();
//        $("#searching").hide();
    });
    
    $('#dept_chooser').change(function() {
        var val = $("#dept_chooser option:selected").text();
        if(val!='Principal'){
            load_des(val);
        }else{
        	load_principal_details();
        }
    });
    
    $('#des_chooser').change(function() {
        var val = $("#des_chooser option:selected").text();
        if(val!='Student'){
            load_names(val);
        }else{
        	console.log('loading year');
        	load_year();
        	console.log('loaded year');
        }
    });
    
    $('#name_chooser').change(function() {
        var val = $("#name_chooser option:selected").text();
        if(val!='All'){
            load_name_details(val);
        }
    });
    
    var i;
    $('#estb_year').empty();
    for(i=1998;i<=new Date().getFullYear();i++){
    	$('#estb_year').append('<option value="'+i+'">'+i+'</option>').material_select();
    }
    
    
    $('#select_des').change(function() {
        var val = $("#select_des option:selected").text();
        if(val.indexOf('Others')>0){
        	console.log(val);
        	$('#select_des').attr('disabled','disabled').material_select();
        	$('#create_des_div').slideToggle('slow');
        }
    });
});


function create_new_des(){
	var val=$('#new_des').val();
	if(/[a-z]/.test(val.toLowerCase())){
		$('#others_des').remove();
		$('#select_des').material_select();
		$('#select_des').append('<option value="'+val+'" selected>'+val+'</option>').material_select();
		$('#select_des').append('<option id="others_des" value="Others">Others</option>').material_select();
		$('#create_des_div').slideToggle('slow');
		$('#select_des').removeAttr('disabled').material_select();
	}else{
		alert('Please use a valid designation name');
	}
}

function cancel_new_des(){
	$('#others_des').remove();
	$('#select_des').append('<option id="others_des" value="Others">Others</option>').material_select();
	$('#create_des_div').slideToggle('slow');
	$('#select_des').removeAttr('disabled').material_select();
}

var set_page;
var total_page;
var active_users_details;
var quered_id;

function show_element(elmnt_id){
    $('#'+elmnt_id).show();
}

function hide_element(elmnt_id){
    $('#'+elmnt_id).hide();
}

function load_principal(){
    $('#selected').text('Principal');
    hide_element('dept_form');
    hide_element('error_chip');
    hide_element('staff_form');
    $.ajax({
        type:'post',
        url:'function_handler.php?check_principal=true',                
        success: function(value){
            if(value=='Y'){
                $('#principal_form').show();
            }else{
                Materialize.toast('The Principal account is already created! To reset the account, please delete it from overview panel.', 7000);
            }
        }
    });
}

function load_staff_form(){
    $('#selected').text('Other Staffs');
    show_element('staff_form');
    hide_element('dept_form');
    hide_element('principal_form');
    hide_element('error_chip');
}

function load_dept_form(){
    $('#selected').text('Department & HOD');
    show_element('dept_form');
    hide_element('staff_form');
    hide_element('principal_form');
    hide_element('error_chip');
}

function mark_no_update(){
    $("#notices").append('<h5 style="font-weight:300">Nothing to show</h5>');
}



//notice & notifications related stuffs

function enlist_notice_read(title,from,time,date,ntf_id){
    var str="loading...";
    $("#notices").append('<li>\n\
                                <div class="collapsible-header" id="'+ntf_id+'" onclick="load_message(this)"><i id="unread'+ntf_id+'" class="material-icons green-text">done</i>'+title+'</div>\n\
                                <div class="collapsible-body">\n\
                                    <p style="padding-bottom:15px">'+time+'<snap style="float:right"> '+date+'</snap><br>'+from+'</p>\n\
                                    <p id="'+ntf_id+'_content" style="padding-top:0px">loading...</p>\n\
                                </div>\n\
                            </li>');
}

function enlist_notice_unread(title,from,time,date,ntf_id){
    $("#notices").append('<li>\n\
                                <div class="collapsible-header" id="'+ntf_id+'" onclick="load_message(this)"><i id="unread'+ntf_id+'" class="material-icons red-text">info_outline</i>'+title+'</div>\n\
                                <div class="collapsible-body">\n\
                                    <p style="padding-bottom:15px">'+time+'<snap style="float:right"> '+date+'</snap><br>'+from+'</p>\n\
                                    <p id="'+ntf_id+'_content" style="padding-top:0px">Loading...</p>\n\
                                </div>\n\
                            </li>');
}

function load_message(elmnt){
    Materialize.toast('Loading in a moment', 2000);
    var id=$(elmnt).attr('id');
    $.ajax({
        type:'post',
        url:"get_ntf.php?ntf_id="+id,                
        success: function(value){
            $("#"+id+"_content").html(value);
        }
    });
}

function mark_read(ntf_id) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        xhttp.responseText;
    };
    xhttp.open("GET", "process_request.php?ntf_id="+ntf_id+"&mark_read=true", true);
    xhttp.send();
//    $("#"+ntf_id).remove();
}

function mark_all_read() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        xhttp.responseText;
    };
    xhttp.open("POST", "process_request.php?mark_notifications=true", true);
    xhttp.send();
    $("#updates").find("tr:gt(0)").remove();
    new_row="<tr><td>No new updates</td><td> </td><td> </td></tr>";
    $("#updates").append(new_row);
}



//preference settings functions

function load_year(){
	var dept = $("#dept_chooser option:selected").text();
	$('#loading_year').show();
	$('#year_chooser').empty();
	$.ajax({
		type:'post',
		url:'function_handler.php?dept='+dept+'&get_years=true',
		success: function(value){
			var i;
			for(i=1;i<=value;i++){
				if(i==1){
					$('#year_chooser').append('	<input name="group2" type="radio" value="1" id="yr1" />\n\
	      										<label for="yr1">1st Year</label>');
				}
				else if(i==2){
					$('#year_chooser').append('	<input name="group2" type="radio" value="2" id="yr2" />\n\
												<label for="yr2">2nd Year</label>');
				}
				else if(i==3){
					$('#year_chooser').append('	<input name="group2" type="radio" value="3" id="yr3" />\n\
												<label for="yr3">3rd Year</label>');
				}
				else if(i>3){
					$('#year_chooser').append('	<input name="group2" type="radio" value="'+i+'" id="yr'+i+'" />\n\
												<label for="yr'+i+'">'+i+'th Year</label>');
				}
			}
			$('#loading_year').hide();
			$('#year_chooser').show();
		}
	});
}

function load_des(dept){
    $('#des_chooser').empty();
    $('#des_chooser').append('<option disabled selected value="">Select Designation</option>');
    $('#loading_des').show();
    $.ajax({
        type:'post',
        url:"function_handler.php?dept="+dept+"&get_designations=true",                
        success: function(value){
            var des=value.split('/');
            $.each(des,function(index, val){
                $('#des_chooser').append('<option value="'+val+'">'+val+'</option>');
            });
            $('#loading_des').hide();
        }
    });
}

function load_names(des){
    $('#name_chooser').empty();
    $('#name_chooser').append('<option disabled selected value="">Select Person</option>');
    $('#name_chooser').append('<option value="">All</option>');
    var dept = $("#dept_chooser option:selected").text();
    $('#loading_name').show();
    $.ajax({
        type:'post',
        url:"function_handler.php?dept="+dept+"&des="+des+"&get_names=true",                
        success: function(value){
            var des=value.split('/');
            $.each(des,function(index, val){
                $('#name_chooser').append('<option value="'+val+'">'+val+'</option>');
            });
            $('#loading_name').hide();
        }
    });
}

function load_name_details(name){
    var dept= $("#dept_chooser option:selected").text();
    var des= $("#des_chooser option:selected").text();
    $("#searching").show();
    $("#result_panel").show();
    $.ajax({
        type:'post',
        url:"function_handler.php?dept="+dept+"&des="+des+"&name="+name+"&get_name_details=true",                
        success: function(value){
            active_users_details=value;
            quered_id=1;
            enlist_quered_users(1)
            $('#searching').hide();
        }
    });
}

function load_principal_details(){
	var dept= 'AEC';
    var des= 'Principal';
    $('#name_chooser').empty();
    $('#name_chooser').append('<option disabled selected value="">Select Person</option>');
    $('#des_chooser').empty();
    $('#des_chooser').append('<option disabled selected value="">Select Designation</option>');
    $("#searching").show();
    $("#result_panel").show();
    $.ajax({
        type:'post',
        url:"function_handler.php?dept=AEC&des=Principal&get_name_details=true",                
        success: function(value){
            active_users_details=value;
            quered_id=1;
            enlist_quered_users(1)
            $('#searching').hide();
        }
    });
}



//pagination of quered users details

function load_quered_users(elmnt){    
    $("#searching").show();
    $("#result_panel").show();
    quered_id=elmnt;
    var str;
    if(elmnt==1){
        str="function_handler.php?id=adm_users_details&load_dean_quered_profile=true";
    }else if(elmnt==2){
        str="function_handler.php?id=queued_users&load_dean_quered_profile=true";
    }else if(elmnt==3){
        str="function_handler.php?id=restricted_users&load_dean_quered_profile=true";
    }else if(elmnt==4){
        str="function_handler.php?id=deleted_users&load_dean_quered_profile=true";
    }
    $.ajax({
        type:'post',
        url:str,
        success: function(value){
            active_users_details=value;
            enlist_quered_users(1)
            $("#searching").hide();
            load_pagination();
        }
    });
}

function load_pagination(){
    set_page=1;
    $("#page_counter").empty();
    var rows=active_users_details.split('/=/');
    if(rows.length%2>0){
        total_page=parseInt(rows.length/2+1);
    }else{
        total_page=rows.length/2;
    }
    
    $("#page_counter").append('<li class="disabled" id="pre_page"><a href="#!" onclick="pre_page()"><i class="material-icons">chevron_left</i></a></li>');
    var i;
    for(i=1;i<=total_page;i++){
        if(i===1){
            $("#page_counter").append('<li class="active" id="page_link_'+i+'"><a href="#!" id="page_'+i+'" onclick="load_page(this)">1</a></li>');
        }else{
            $("#page_counter").append('<li class="waves-effect" id="page_link_'+i+'" ><a href="#!" id="page_'+i+'" onclick="load_page(this)">'+i+'</a></li>');
        }
    }
    $("#page_counter").append('<li class="waves-effect" id="next_page"><a href="#!" onclick="next_page()"><i class="material-icons">chevron_right</i></a></li>');
    if(total_page>1){
        $("#page_counter").show();
    }else{
        $("#page_counter").hide();
    }
}

function pre_page(){
    if(set_page>1){
        $("#page_link_"+set_page).addClass('waves-effect').removeClass('active');
        set_page=set_page-1;
        $("#page_link_"+set_page).addClass('active').removeClass('waves-effect');
        load_page1(set_page);
    }
}

function next_page(){
    if(set_page<total_page){
        $("#page_link_"+set_page).addClass('waves-effect').removeClass('active');
        set_page=set_page+1;
        $("#page_link_"+set_page).addClass('active').removeClass('waves-effect');
        load_page1(set_page);
    }
}

function load_page(elmnt){
    var id=$(elmnt).attr('id');
    $("#page_link_"+set_page).addClass('waves-effect').removeClass('active');
    set_page=parseInt(id.split('_')[1]);
    $("#page_link_"+set_page).addClass('active').removeClass('waves-effect');
    load_page1(set_page);
}

function load_page1(n){
    if(n===1){
        $("#pre_page").addClass('disabled').removeClass('waves-effect');
        $("#next_page").addClass('waves-effect').removeClass('disabled');
    }else if(n===total_page){
        $("#next_page").addClass('disabled').removeClass('waves-effect');
        $("#pre_page").addClass('waves-effect').removeClass('disabled');
    }else{
        $("#pre_page").addClass('waves-effect').removeClass('disabled');
        $("#next_page").addClass('waves-effect').removeClass('disabled');
    }
    enlist_quered_users(n);
}

function enlist_quered_users(n){
    $("#results").empty();
    var rows=active_users_details.split('/=/');
    var i;
    for(i=n*2-2;i<n*2;i++){
        if(i<rows.length){
            var column=rows[i].split('/+/');
            if(quered_id==1){
                enlist_profile(column);    
            }else if(quered_id==2){
                enlist_profile2(column);    
            }else if(quered_id==3){
                enlist_profile3(column);    
            }else if(quered_id==4){
                enlist_profile4(column);    
            }
        }
    }
}

function enlist_profile(data){
    var user_id=data[0];
    var name=data[1];
    var contact=data[7];
    var des=data[6];
    var dept=data[5];
    var f_name=data[10];
    var email=data[2];
    var city=data[8];
    var DOB=data[9];
    var enrol_date=data[3];
    var discharge_date=data[4];
    var profile_pic=data[11];
    
    $("#results").append('<li>\n\
                                <div class="collapsible-header" id="'+user_id+'" onclick="load_profile_pic(this)"><i class="material-icons green-text">account_circle</i>'+name+'<span style="float: right">'+des+', '+dept+'</span></div>\n\
                                <div class="collapsible-body">\n\
                                    <div class="row" id="loading" style="display:none">\n\
                                        <img src="loader.gif">\n\
                                    </div>\n\
                                    <div class="row">\n\
                                        <!--profile pic-->\n\
                                        <div class="col s3 m2">\n\
                                            <div class="card">\n\
                                                <div class="card-image" id="profile_'+user_id+'">\n\
                                                    <img src="profile/default.png">\n\
                                                </div>\n\
                                            </div>\n\
                                        </div>\n\
                                        <div class="col s3 m10">\n\
                                            <div class="col s3 m12">\n\
                                                <p class="profile-content"><span class="profile-head">'+name+'</span><br>\n\
                                                <span class="profile-subhead">'+des+', '+dept+'</span></p>\n\
                                            </div>\n\
                                            <div class="col s3 m6">\n\
                                                <p class="profile-content">\n\
                                                Contact: <span class="content-color">'+contact+'</span><br>\n\
                                                Email: <span class="content-color">'+email+'</span><br>\n\
                                                DOB: <span class="content-color">'+DOB+'</span><br>\n\
                                                Father Name: <span class="content-color">'+f_name+'</span>\n\
                                            </p>\n\
                                            </div>\n\
                                            <div class="col s3 m6">\n\
                                                <p class="profile-content">\n\
                                                    City: <span class="content-color">'+city+'</span><br>\n\
                                                    Enroll Date: <span class="content-color">'+enrol_date+'</span><br>\n\
                                                    Discharge Date: <span class="content-color">'+discharge_date+'</span><br>\n\
                                                </p>\n\
                                            </div>\n\
                                        </div>\n\
                                    </div>\n\
                                    <div class="card-action">\n\
                                        <a href="#">Resend request</a>\n\
                                        <a href="#">Delete</a>\n\
                                    </div>\n\
                                </div>\n\
                            </li>');
}

function enlist_profile2(data){
    var user_id=data[0];
    var name=data[2];
    var email=data[3];
    var des=data[4];
    var dept=data[5];
    var contact='NA';
    var f_name='NA';
    var city='NA';
    var DOB='NA';
    var enrol_date='NA';
    var discharge_date='NA';
    
    $("#results").append('<li>\n\
                                <div class="collapsible-header" id="'+user_id+'"><i class="material-icons yellow-text">account_circle</i>'+name+'<span style="float: right">'+des+', '+dept+'</span></div>\n\
                                <div class="collapsible-body">\n\
                                    <div class="row" style="padding:10px">\n\
                                        <h4 style="margin:auto;color:red;font-weight:lighter">Account not activated yet (id:'+user_id+')</h4>\n\
                                    </div>\n\
                                    <div class="row" id="loading" style="display:none">\n\
                                        <img src="loader.gif">\n\
                                    </div>\n\
                                    <div class="row">\n\
                                        <!--profile pic-->\n\
                                        <div class="col s3 m2">\n\
                                            <div class="card">\n\
                                                <div class="card-image">\n\
                                                    <img src="profile/default.png">\n\
                                                </div>\n\
                                            </div>\n\
                                        </div>\n\
                                        <div class="col s3 m10">\n\
                                            <div class="col s3 m12">\n\
                                                <p class="profile-content"><span class="profile-head">'+name+'</span><br>\n\
                                                <span class="profile-subhead">'+des+', '+dept+'</span></p>\n\
                                            </div>\n\
                                            <div class="col s3 m6">\n\
                                                <p class="profile-content">\n\
                                                Contact: <span class="content-color">'+contact+'</span><br>\n\
                                                Email: <span class="content-color">'+email+'</span><br>\n\
                                                DOB: <span class="content-color">'+DOB+'</span><br>\n\
                                                Father Name: <span class="content-color">'+f_name+'</span>\n\
                                            </p>\n\
                                            </div>\n\
                                            <div class="col s3 m6">\n\
                                                <p class="profile-content">\n\
                                                    City: <span class="content-color">'+city+'</span><br>\n\
                                                    Enroll Date: <span class="content-color">'+enrol_date+'</span><br>\n\
                                                    Discharge Date: <span class="content-color">'+discharge_date+'</span><br>\n\
                                                </p>\n\
                                            </div>\n\
                                        </div>\n\
                                    </div>\n\
                                    <div class="card-action">\n\
                                        <a href="#">Resend request</a>\n\
                                        <a href="#">Delete</a>\n\
                                    </div>\n\
                                </div>\n\
                            </li>');
}

function enlist_profile3(data){
    var user_id=data[0];
    var name=data[1];
    var contact=data[7];
    var des=data[6];
    var dept=data[5];
    var f_name=data[10];
    var email=data[2];
    var city=data[8];
    var DOB=data[9];
    var enrol_date=data[3];
    var discharge_date=data[4];
    var profile_pic=data[11];
    
    $("#results").append('<li>\n\
                                <div class="collapsible-header" id="'+user_id+'" onclick="load_profile_pic(this)"><i class="material-icons red-text">account_circle</i>'+name+'<span style="float: right">'+des+', '+dept+'</span></div>\n\
                                <div class="collapsible-body">\n\
                                    <div class="row" style="padding:10px">\n\
                                        <h4 style="margin:auto;color:red;font-weight:lighter">User is restricted (id:'+user_id+')</h4>\n\
                                    </div>\n\
                                    <div class="row" id="loading" style="display:none">\n\
                                        <img src="loader.gif">\n\
                                    </div>\n\
                                    <div class="row">\n\
                                        <!--profile pic-->\n\
                                        <div class="col s3 m2">\n\
                                            <div class="card">\n\
                                                <div class="card-image" id="profile_'+user_id+'">\n\
                                                    <img src="profile/default.png">\n\
                                                </div>\n\
                                            </div>\n\
                                        </div>\n\
                                        <div class="col s3 m10">\n\
                                            <div class="col s3 m12">\n\
                                                <p class="profile-content"><span class="profile-head">'+name+'</span><br>\n\
                                                <span class="profile-subhead">'+des+', '+dept+'</span></p>\n\
                                            </div>\n\
                                            <div class="col s3 m6">\n\
                                                <p class="profile-content">\n\
                                                Contact: <span class="content-color">'+contact+'</span><br>\n\
                                                Email: <span class="content-color">'+email+'</span><br>\n\
                                                DOB: <span class="content-color">'+DOB+'</span><br>\n\
                                                Father Name: <span class="content-color">'+f_name+'</span>\n\
                                            </p>\n\
                                            </div>\n\
                                            <div class="col s3 m6">\n\
                                                <p class="profile-content">\n\
                                                    City: <span class="content-color">'+city+'</span><br>\n\
                                                    Enroll Date: <span class="content-color">'+enrol_date+'</span><br>\n\
                                                    Discharge Date: <span class="content-color">'+discharge_date+'</span><br>\n\
                                                </p>\n\
                                            </div>\n\
                                        </div>\n\
                                    </div>\n\
                                    <div class="card-action">\n\
                                        <a href="#">Send message to email</a>\n\
                                        <a href="#">Remove restriction</a>\n\
                                        <a href="#">Delete</a>\n\
                                    </div>\n\
                                </div>\n\
                            </li>');
}

function enlist_profile4(data){
    var user_id=data[0];
    var name=data[1];
    var contact=data[7];
    var des=data[6];
    var dept=data[5];
    var f_name=data[10];
    var email=data[2];
    var city=data[8];
    var DOB=data[9];
    var enrol_date=data[3];
    var discharge_date=data[4];
    var profile_pic=data[11];
    
    $("#results").append('<li>\n\
                                <div class="collapsible-header" id="'+user_id+'" onclick="load_profile_pic(this)"><i class="material-icons black-text">account_circle</i>'+name+'<span style="float: right">'+des+', '+dept+'</span></div>\n\
                                <div class="collapsible-body">\n\
                                    <div class="row" style="padding:10px">\n\
                                        <h4 style="margin:auto;color:red;font-weight:lighter">Account will be permanently deleted in next 48hrs (id:'+user_id+')</h4>\n\
                                    </div>\n\
                                    <div class="row" id="loading" style="display:none">\n\
                                        <img src="loader.gif">\n\
                                    </div>\n\
                                    <div class="row">\n\
                                        <!--profile pic-->\n\
                                        <div class="col s3 m2">\n\
                                            <div class="card">\n\
                                                <div class="card-image" id="profile_'+user_id+'">\n\
                                                    <img src="profile/default.png">\n\
                                                </div>\n\
                                            </div>\n\
                                        </div>\n\
                                        <div class="col s3 m10">\n\
                                            <div class="col s3 m12">\n\
                                                <p class="profile-content"><span class="profile-head">'+name+'</span><br>\n\
                                                <span class="profile-subhead">'+des+', '+dept+'</span></p>\n\
                                            </div>\n\
                                            <div class="col s3 m6">\n\
                                                <p class="profile-content">\n\
                                                Contact: <span class="content-color">'+contact+'</span><br>\n\
                                                Email: <span class="content-color">'+email+'</span><br>\n\
                                                DOB: <span class="content-color">'+DOB+'</span><br>\n\
                                                Father Name: <span class="content-color">'+f_name+'</span>\n\
                                            </p>\n\
                                            </div>\n\
                                            <div class="col s3 m6">\n\
                                                <p class="profile-content">\n\
                                                    City: <span class="content-color">'+city+'</span><br>\n\
                                                    Enroll Date: <span class="content-color">'+enrol_date+'</span><br>\n\
                                                    Discharge Date: <span class="content-color">'+discharge_date+'</span><br>\n\
                                                </p>\n\
                                            </div>\n\
                                        </div>\n\
                                    </div>\n\
                                    <div class="card-action">\n\
                                        <a href="#">Send message to email</a>\n\
                                        <a href="#">Remove restriction</a>\n\
                                        <a href="#">Delete</a>\n\
                                    </div>\n\
                                </div>\n\
                            </li>');
}

function load_profile_pic(elmnt){
    var id=$(elmnt).attr('id');
    $.ajax({
        type:'post',
        url:"function_handler.php?user_id="+id+"&get_profile_pic=true",                
        success: function(value){
            $('#profile_'+id).empty();
            $('#profile_'+id).append('<img src="'+value+'">');
        }
    });
}
