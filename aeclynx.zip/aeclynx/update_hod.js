
$(document).ready(function() {
	$('select').material_select();

	load_year();
});


function load_year(){
	
	$.ajax({
        type:'post',
        url:'function_handler.php?get_years=true',                
        success: function(value){

        	console.log('dept::'+value);
            var i;
        	for(i=1;i<=value;i++){
        		if(i==1){
        			$('#year').append('<option value="1">1st Year</option>');
        		}else if(i==2){
        			$('#year').append('<option value="2">2nd Year</option>');
        		}else if(i==3){
        			$('#year').append('<option value="3">3rd Year</option>');
        		}else if(i>3){
        			$('#year').append('<option value="'+i+'">'+i+'th Year</option>');
        		}
        		$('#year').material_select();
            }
        }
    });
}


function show_element(elmnt_id){
    $('#'+elmnt_id).show();
}

function hide_element(elmnt_id){
    $('#'+elmnt_id).hide();
}





//notice & notifications related stuffs

function enlist_notice_read(title,from,time,date,ntf_id){
  var str="loading...";
  $("#notices").append('<li>\n\
                              <div class="collapsible-header" id="'+ntf_id+'" onclick="load_message(this)"><i id="unread'+ntf_id+'" class="material-icons green-text">done</i>'+title+'</div>\n\
                              <div class="collapsible-body">\n\
                                  <p style="padding-bottom:15px">'+time+'<snap style="float:right"> '+date+'</snap><br>'+from+'</p>\n\
                                  <p id="'+ntf_id+'_content" style="padding-top:0px">loading...</p>\n\
                              </div>\n\
                          </li>');
}

function enlist_notice_unread(title,from,time,date,ntf_id){
  $("#notices").append('<li>\n\
                              <div class="collapsible-header" id="'+ntf_id+'" onclick="load_message(this)"><i id="unread'+ntf_id+'" class="material-icons red-text">info_outline</i>'+title+'</div>\n\
                              <div class="collapsible-body">\n\
                                  <p style="padding-bottom:15px">'+time+'<snap style="float:right"> '+date+'</snap><br>'+from+'</p>\n\
                                  <p id="'+ntf_id+'_content" style="padding-top:0px">Loading...</p>\n\
                              </div>\n\
                          </li>');
}

function load_message(elmnt){
  Materialize.toast('Loading in a moment', 2000);
  var id=$(elmnt).attr('id');
  $.ajax({
      type:'post',
      url:"get_ntf.php?ntf_id="+id,                
      success: function(value){
          $("#"+id+"_content").html(value);
      }
  });
}

function mark_read(ntf_id) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
      xhttp.responseText;
  };
  xhttp.open("GET", "process_request.php?ntf_id="+ntf_id+"&mark_read=true", true);
  xhttp.send();
//  $("#"+ntf_id).remove();
}

function mark_all_read() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
      xhttp.responseText;
  };
  xhttp.open("POST", "process_request.php?mark_notifications=true", true);
  xhttp.send();
  $("#updates").find("tr:gt(0)").remove();
  new_row="<tr><td>No new updates</td><td> </td><td> </td></tr>";
  $("#updates").append(new_row);
}

function mark_no_update(){
    $("#notices").append('<h5 style="font-weight:300">Nothing to show</h5>');
}

