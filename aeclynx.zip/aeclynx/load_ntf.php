<?php
error_reporting(0);
include 'new_con.php';

$table=$_SESSION['username'].'_MSG';
$stmt="SELECT * from ".$table;

$result=mysqli_query($con, $stmt);

if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_row($result)){
        $from=$row[2];
        $opened=$row[7];
        $title=$row[4];
        $time=$row[0];
        $date=$row[1];
        $content=$row[5];
        $ntf_id=$row[8];
        //echo $from.', '.$title.', '.$time.', '.$date;
        if($opened=='F'){
            echo '<script type="text/javascript">enlist_notice_unread("'.$title.'","'.$from.'","'.$time.'","'.$date.'","'.$ntf_id.'");</script>';
        }else{
            echo '<script type="text/javascript">enlist_notice_read("'.$title.'","'.$from.'","'.$time.'","'.$date.'","'.$ntf_id.'");</script>';
        }
    }
}else{
    echo '<script type="text/javascript">mark_no_update();</script>';
}