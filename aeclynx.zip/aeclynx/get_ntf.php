<?php
error_reporting(0);
include 'base.php';

$table=$_SESSION['username']."_MSG";
$stmt="SELECT * from ".$table." where ntf_id='".$_GET['ntf_id']."'";

$result=mysqli_query($con, $stmt);

if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_row($result)){
        $content=$row[5];
        $read=$row[7];
        if($read=="F"){
            mysqli_query($con, "UPDATE ".$table." SET opened='T' where ntf_id='".$_GET['ntf_id']."'");
        }
        print nl2br( $content );
    }
}