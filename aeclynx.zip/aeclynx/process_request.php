<?php
error_reporting(0);
include 'base.php';

if(isset($_GET['mark_notifications'])){
    mark_notifications($con);
}elseif(isset($_GET['mark_read'])){
    mark_read($con,$_GET['ntf_id']);
}elseif(isset($_GET['delete_all_ntf'])){
    delete_all_ntf($con);
}

function mark_notifications($con){
    $user=$_SESSION['username'];
    $stmt="UPDATE ".$user."_MSG SET opened='T' where opened='F'";
    if(mysqli_query($con, $stmt)){
        header("Refresh:0; url=home.php?load_notifications=true");
    }else{
        echo 'error: '. mysqli_error($con);
    }
}

function mark_read($con,$ntf_id){
    $user=$_SESSION['username'];
    $stmt="UPDATE ".$user."_MSG SET opened='T' where ntf_id='".$ntf_id."'";
    if(mysqli_query($con, $stmt)){
        header("Refresh:0; url=index.php");
    }else{
        echo 'error12: '. mysqli_error($con);
    }
}

function delete_all_ntf($con){
    $user=$_SESSION['username'];
    $stmt="TRUNCATE ".$user."_MSG";
    if(mysqli_query($con, $stmt)){
        header("Refresh:0; url=home.php?load_notifications=true");
    }else{
        echo 'error12: '. mysqli_error($con);
    }
}
?>
